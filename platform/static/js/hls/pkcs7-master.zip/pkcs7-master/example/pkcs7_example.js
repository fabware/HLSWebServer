'use strict';

var pkcs7 = require('../lib/pkcs7.js');

pkcs7.awesome();
// => awesome