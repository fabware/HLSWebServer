<!-- GENERATED FROM SOURCE -->

# vjs.media


---

## INDEX

- [UNDEFINED](#undefined)
  - [ApiMethods](#apimethods)

---

## UNDEFINED

### ApiMethods
> List of default API methods for any MediaTechController

_defined in_: [src/js/media/media.js#L169](https://github.com/videojs/video.js/blob/master/src/js/media/media.js#L169)

---

